
document.getElementById('uploadForm').addEventListener('submit', function(e) {
    e.preventDefault();
    alert('Note uploaded successfully!');
  });