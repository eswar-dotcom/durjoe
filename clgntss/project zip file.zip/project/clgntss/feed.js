
window.onload = function() {
    document.getElementById('loader').style.display = 'none';
  };